import React from 'react';

export function Footer() {
  return (
    <footer>
    <div className="container">
        <p>&copy; 2022 University of Washington - The Information School</p>
    </div>
    </footer>
  );
}
