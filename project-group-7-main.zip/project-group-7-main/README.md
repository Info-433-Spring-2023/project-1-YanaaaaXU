# INFO 340 Project

This repository contains code for an interactive information web app, created for the _Client-Side Web Development_ course at the UW iSchool.
